<div class="footer-nav-area" id="footerNav">
  <div class="container px-0">
    <!-- Paste your Footer Content from here-->
    <!-- Footer Content-->
    <div class="footer-nav position-relative">
      <ul class="h-100 d-flex align-items-center justify-content-between ps-0">
        <li class="active"><a href="<?=base_url()?>home"><img src="<?=base_url()?>assets/img/bg-img/ic_home.png"/><span style="color: #a3a3a3">Home</span></a></li>
        <li><a href="<?=base_url()?>company"><img src="<?=base_url()?>assets/img/bg-img/ic_building.png"/><span style="color: #a3a3a3">Company</span></a></li>
        <li><a href="<?=base_url()?>info"><img src="<?=base_url()?>assets/img/bg-img/ic_info.png"/><span style="color: #a3a3a3">Info</span></a></li>
        <li><a href="<?=base_url()?>profile"><img src="<?=base_url()?>assets/img/bg-img/ic_profile.png"/><span style="color: #a3a3a3">Profile</span></a></li>
      </ul>
    </div>
  </div>
</div>